from selenium.webdriver.common.by import By


class HomePage:
    def __init__(self, driver):
        self.driver=driver


    name=(By.XPATH, "//div[@class='form-group']/input[@name='name']")
    email = (By.NAME, 'email')
    PWD=(By.ID,'exampleInputPassword1')
    check_box=(By.ID, 'exampleCheck1')


    def Name_Item(self):
        return self.driver.find_element(*HomePage.name)

    def Email_Item(self):
        return self.driver.find_element(*HomePage.email)

    def PWD_Item(self):
        return self.driver.find_element(*HomePage.PWD)

    def Ceck_Box(self):
        return self.driver.find_element(*HomePage.check_box)
