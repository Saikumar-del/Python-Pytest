from selenium.webdriver.common.by import By


class CheckOutPage:
    def __init__(self, driver):
        self.driver=driver


    shop = (By.XPATH, "//div[@class='container']/nav/ul/li[2]/a")
    afterselect_mobile = (By.XPATH, '//a[@class="nav-link btn btn-primary"]')
    checuout_button = (By.XPATH, "//button[@class='btn btn-success']")

    def ShopItems(self):
        return self.driver.find_element(*CheckOutPage.shop)

    def ClickButton1(self):
        return self.driver.find_element(*CheckOutPage.afterselect_mobile)

    def CheckOut_Button(self):
        return self.driver.find_element(*CheckOutPage.checuout_button)
