from selenium.webdriver.common.by import By


class SuccessPage:

    def __int__(self,driver):
        self.driver=driver

    check=(By.XPATH, "//div[@class='checkbox checkbox-primary']")
    Success=(By.XPATH, "//input[@class='btn btn-success btn-lg']")


    def Check_Box(self):
        return self.driver.find_element(*SuccessPage.check)

    def Success_Message(self):
        return self.driver.find_element(*SuccessPage.Success)