import time
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.service import Service
# s = Service("C:\\chromedriver.exe")
# driver=webdriver.Chrome(service=s)
from selenium.webdriver.support import expected_conditions
from selenium.webdriver.support.select import Select
from selenium.webdriver.support.wait import WebDriverWait

from PageObject.CheckOutPage import CheckOutPage
from PageObject.HomePage import HomePage
from PageObject.SuccessPage import SuccessPage
from utility.BaseClass import BaseClass


class TestOne(BaseClass):
    def test_e2e(self,setup):

        # driver=webdriver.Chrome("C:\\chromedriver.exe")
        # driver.get('https://rahulshettyacademy.com/angularpractice/')
        #self.driver.find_element(By.XPATH, "//div[@class='form-group']/input[@name='name']").send_keys('SaiKumar')
        Name=HomePage(self.driver)
        Name.Name_Item().send_keys('SaiKumar')
        #self.driver.find_element(By.NAME, 'email').send_keys('SaiKumar@gmail.com')
        Email=HomePage(self.driver)
        Email.Email_Item().send_keys('SaiKumar@gmail.com')
        #self.driver.find_element(By.ID, 'exampleInputPassword1').send_keys('SaiKumar123')
        password=HomePage(self.driver)
        password.PWD_Item().send_keys('SaiKumar123')
        #self.driver.find_element(By.ID, 'exampleCheck1').click()
        check=HomePage(self.driver)
        check.Ceck_Box().click()
        Gen=Select(self.driver.find_element(By.ID, 'exampleFormControlSelect1'))
        Gen.select_by_visible_text('Female')
        self.driver.find_element(By.XPATH, "//input[@class='btn btn-success']").click()
        #self.driver.find_element(By.XPATH, "//div[@class='container']/nav/ul/li[2]/a").click()
        homepage=CheckOutPage(self.driver)
        homepage.ShopItems().click()
        mobiles = self.driver.find_elements(By.XPATH, "//div[@class='card h-100']")
        for mobile in mobiles:
            productName = mobile.find_element(By.XPATH, "div/h4/a").text
            if productName == "Blackberry":
                mobile.find_element(By.XPATH, "div/button").click()

        #self.driver.find_element(By.XPATH, '//a[@class="nav-link btn btn-primary"]').click()
        button = CheckOutPage(self.driver)
        button.ClickButton1().click()
        #Checkoutpage
        #self.driver.find_element(By.XPATH, "//button[@class='btn btn-success']").click()
        checkout=CheckOutPage(self.driver)
        checkout.CheckOut_Button().click()
        self.driver.find_element(By.ID, "country").send_keys("ind")
        wait = WebDriverWait(self.driver, 10)
        wait.until(expected_conditions.presence_of_element_located((By.LINK_TEXT, "India")))
        self.driver.find_element(By.LINK_TEXT, "India").click()
        #self.driver.find_element(By.XPATH, "//div[@class='checkbox checkbox-primary']").click()
        che=SuccessPage(self.driver)
        che.Check_Box.click()
        #self.driver.find_element(By.XPATH, "//input[@class='btn btn-success btn-lg']").click()
        Succes=SuccessPage(self.driver)
        Succes.Success_Message().click()
        success = self.driver.find_element(By.XPATH, "//div[@class='alert alert-success alert-dismissible']").text
        assert 'Success! Thank you!' in success

        time.sleep(5)
        self.driver.close()