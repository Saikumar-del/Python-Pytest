import pytest
from selenium import webdriver

@pytest.fixture(scope='class')
def setup(request):
    driver = webdriver.Chrome("C:\\chromedriver.exe")
    driver.get('https://rahulshettyacademy.com/angularpractice/')
    driver.maximize_window()
    request.cls.driver = driver
